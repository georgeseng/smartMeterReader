Filelist:
SAME54_Xplained_Pro_layer_plots_release_rev4.pdf : PCB Layer Plots
BOM\Bill of Materials Print- SAME54_Xplained_Pro_release_rev4.xls : BOM, fitted components
ExportSTEP\SAME54_Xplained_Pro_release_rev4.step : 3D Model of PCBA
NC Drill\SAME54_Xplained_Pro_release_rev4.drl : Drill files, gerber
NC Drill\SAME54_Xplained_Pro_release_rev4.drr : Drill Files Report
Pick Place\Pick Place for SAME54_Xplained_Pro_release_rev4.txt : Pick and Place file, component placement
Test Points\Assembly Testpoint Report for SAME54_Xplained_Pro_release_rev4.txt : Assembly Testpoint report, txt
Test Points\Assembly Testpoint Report for SAME54_Xplained_Pro_release_rev4.csv : Assembly Testpoint report, csv
NC Drill\SAME54_Xplained_Pro_-SlotHoles_release_rev4.txt : Drill files, ASCII-SlotHoles
NC Drill\SAME54_Xplained_Pro_-RoundHoles_release_rev4.txt : Drill files, ASCII-RoundHoles
SAME54_Xplained_Pro_design_documentation_release_rev4.pdf : Design Documentation with Bom
Gerber\SAME54_Xplained_Pro_release_rev4.GP1 : Gerber files for GND
Gerber\SAME54_Xplained_Pro_release_rev4.GP2 : Gerber files for POWER
Gerber\SAME54_Xplained_Pro_release_rev4.GM1 : Gerber files for Board (M1)
Gerber\SAME54_Xplained_Pro_release_rev4.GBO : Gerber files for Bottom Overlay
Gerber\SAME54_Xplained_Pro_release_rev4.GBL : Gerber files for Bottom Layer LF-signals
Gerber\SAME54_Xplained_Pro_release_rev4.GBS : Gerber files for Bottom Solder
Gerber\SAME54_Xplained_Pro_release_rev4.GBP : Gerber files for Bottom Paste
Gerber\SAME54_Xplained_Pro_release_rev4.GTP : Gerber files for Top Paste
Gerber\SAME54_Xplained_Pro_release_rev4.GTS : Gerber files for Top Solder
Gerber\SAME54_Xplained_Pro_release_rev4.GTL : Gerber files for Top Layer LF-signals
Gerber\SAME54_Xplained_Pro_release_rev4.GTO : Gerber files for Top Overlay
NC Drill\SAME54_Xplained_Pro_release_rev4.LDP : Layer Pairs Definition
