Filelist:
SAME54_Xplained_Pro_layer_plots_release_rev5.pdf : PCB Layer Plots
BOM\Bill of Materials Print- SAME54_Xplained_Pro_release_rev5.xls : BOM, fitted components
ExportSTEP\SAME54_Xplained_Pro_release_rev5.step : 3D Model of PCBA
NC Drill\SAME54_Xplained_Pro_release_rev5.drl : Drill files, gerber
NC Drill\SAME54_Xplained_Pro_release_rev5.drr : Drill Files Report
Pick Place\Pick Place for SAME54_Xplained_Pro_release_rev5.txt : Pick and Place file, component placement
Test Points\Assembly Testpoint Report for SAME54_Xplained_Pro_release_rev5.txt : Assembly Testpoint report, txt
Test Points\Assembly Testpoint Report for SAME54_Xplained_Pro_release_rev5.csv : Assembly Testpoint report, csv
NC Drill\SAME54_Xplained_Pro_-SlotHoles_release_rev5.txt : Drill files, ASCII-SlotHoles
NC Drill\SAME54_Xplained_Pro_-RoundHoles_release_rev5.txt : Drill files, ASCII-RoundHoles
SAME54_Xplained_Pro_design_documentation_release_rev5.pdf : Design Documentation with Bom
Gerber\SAME54_Xplained_Pro_release_rev5.GP1 : Gerber files for GND
Gerber\SAME54_Xplained_Pro_release_rev5.GP2 : Gerber files for POWER
Gerber\SAME54_Xplained_Pro_release_rev5.GM1 : Gerber files for Board (M1)
Gerber\SAME54_Xplained_Pro_release_rev5.GBO : Gerber files for Bottom Overlay
Gerber\SAME54_Xplained_Pro_release_rev5.GBL : Gerber files for Bottom Layer LF-signals
Gerber\SAME54_Xplained_Pro_release_rev5.GBS : Gerber files for Bottom Solder
Gerber\SAME54_Xplained_Pro_release_rev5.GBP : Gerber files for Bottom Paste
Gerber\SAME54_Xplained_Pro_release_rev5.GTP : Gerber files for Top Paste
Gerber\SAME54_Xplained_Pro_release_rev5.GTS : Gerber files for Top Solder
Gerber\SAME54_Xplained_Pro_release_rev5.GTL : Gerber files for Top Layer LF-signals
Gerber\SAME54_Xplained_Pro_release_rev5.GTO : Gerber files for Top Overlay
NC Drill\SAME54_Xplained_Pro_release_rev5.LDP : Layer Pairs Definition
